package com.example.economymod;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.Item;

public class EconomyMod implements ModInitializer {
    public static final String MODID = "economymod";

    // ===== Editable settings =====
    public static final long START_MONEY = 500;
    public static final long SLEEP_COST = 50;
    public static final long DEATH_COST = 100;
    public static final long ELYTRA_COST_PER_SECOND = 2;
    public static final long COIN_VALUE = 10;
    public static final long DEBT_GRACE_TICKS = 20 * 60 * 5; // 5 minutes before jail
    public static final int JAIL_ORE_QUOTA = 25;             // ores to mine to get out

    public static Item COIN;

    @Override
    public void onInitialize() {
        Identifier id = Identifier.fromNamespaceAndPath(MODID, "coin");
        ResourceKey<Item> key = ResourceKey.create(Registries.ITEM, id);
        COIN = Registry.register(BuiltInRegistries.ITEM, key, new CoinItem(new Item.Properties().setId(key)));
        ItemGroupEvents.modifyEntriesEvent(CreativeModeTabs.INGREDIENTS).register(e -> e.accept(COIN));
        Events.register();
    }
}
