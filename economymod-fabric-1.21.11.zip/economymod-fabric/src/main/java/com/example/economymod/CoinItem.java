package com.example.economymod;

import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.Level;

public class CoinItem extends Item {
    public CoinItem(Item.Properties p) { super(p); }

    @Override
    public InteractionResult use(Level level, Player player, InteractionHand hand) {
        if (!level.isClientSide() && player instanceof ServerPlayer sp) {
            player.getItemInHand(hand).shrink(1);
            Eco.add(sp, EconomyMod.COIN_VALUE, "coin");
        }
        return InteractionResult.SUCCESS;
    }
}
