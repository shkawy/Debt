package com.example.economymod;

import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.util.RandomSource;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.levelgen.Heightmap;

import java.util.Set;

public class Jail {
    static final BlockPos O = new BlockPos(5000, 100, 5000);
    static final int W = 17, H = 9;

    static void build(ServerLevel l) {
        RandomSource r = l.random;
        Block[] ores = {Blocks.COAL_ORE, Blocks.IRON_ORE, Blocks.COPPER_ORE, Blocks.GOLD_ORE, Blocks.REDSTONE_ORE};
        for (int x = 0; x < W; x++)
            for (int y = 0; y < H; y++)
                for (int z = 0; z < W; z++) {
                    boolean edge = x == 0 || z == 0 || y == 0 || x == W - 1 || z == W - 1 || y == H - 1;
                    boolean pocket = x >= 7 && x <= 9 && z >= 7 && z <= 9 && y >= 1 && y <= 3;
                    Block b;
                    if (edge) b = Blocks.BEDROCK;
                    else if (pocket) b = Blocks.AIR;
                    else b = r.nextInt(100) < 12 ? ores[r.nextInt(ores.length)] : Blocks.STONE;
                    l.setBlock(O.offset(x, y, z), b.defaultBlockState(), 2);
                }
        l.setBlock(O.offset(7, 1, 7), Blocks.TORCH.defaultBlockState(), 2);
        l.setBlock(O.offset(9, 1, 9), Blocks.TORCH.defaultBlockState(), 2);
    }

    static void send(ServerPlayer p) {
        ServerLevel l = Eco.server.overworld();
        if (!Eco.store.jailBuilt) { build(l); Eco.store.jailBuilt = true; }
        if (p.getInventory().countItem(Items.STONE_PICKAXE) == 0)
            p.getInventory().add(new ItemStack(Items.STONE_PICKAXE));
        p.teleportTo(l, O.getX() + 8.5, O.getY() + 1, O.getZ() + 8.5, Set.of(), 0f, 0f, true);
    }

    static void jail(ServerPlayer p) {
        Eco.P s = Eco.of(p);
        s.jailed = true;
        s.mined = 0;
        send(p);
        p.sendSystemMessage(Component.literal("You are in JAIL for unpaid debt! Mine "
                + EconomyMod.JAIL_ORE_QUOTA + " ores to get out."));
    }

    static void release(ServerPlayer p) {
        Eco.P s = Eco.of(p);
        s.jailed = false;
        s.mined = 0;
        s.balance = 0;
        s.debtSince = -1;
        ServerLevel l = Eco.server.overworld();
        BlockPos top = l.getHeightmapPos(Heightmap.Types.MOTION_BLOCKING, BlockPos.ZERO);
        p.teleportTo(l, top.getX() + 0.5, top.getY(), top.getZ() + 0.5, Set.of(), 0f, 0f, true);
        p.sendSystemMessage(Component.literal("You are FREE! Your debt was cleared. Balance: 0$"));
    }
}
