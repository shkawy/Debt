package com.example.economymod;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.storage.LevelResource;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.Map;

public class Eco {
    /** Sell prices. Add more items here. */
    public static final Map<Item, Integer> PRICES = Map.ofEntries(
            Map.entry(Items.COAL, 5), Map.entry(Items.COPPER_INGOT, 8),
            Map.entry(Items.IRON_INGOT, 20), Map.entry(Items.GOLD_INGOT, 40),
            Map.entry(Items.REDSTONE, 4), Map.entry(Items.LAPIS_LAZULI, 6),
            Map.entry(Items.DIAMOND, 150), Map.entry(Items.EMERALD, 100),
            Map.entry(Items.WHEAT, 2), Map.entry(Items.CARROT, 2),
            Map.entry(Items.POTATO, 2), Map.entry(Items.BEEF, 5),
            Map.entry(Items.PORKCHOP, 5), Map.entry(Items.ROTTEN_FLESH, 1),
            Map.entry(Items.BONE, 2), Map.entry(Items.STRING, 2),
            Map.entry(Items.GUNPOWDER, 6), Map.entry(Items.ENDER_PEARL, 30),
            Map.entry(Items.NETHERITE_INGOT, 600), Map.entry(Items.OAK_LOG, 3),
            Map.entry(Items.COBBLESTONE, 1)
    );

    public static class P {
        public long balance = EconomyMod.START_MONEY;
        public long debtSince = -1;
        public boolean jailed = false;
        public int mined = 0;
    }

    public static class Store {
        public Map<String, P> players = new HashMap<>();
        public boolean jailBuilt = false;
    }

    public static MinecraftServer server;
    public static Store store = new Store();
    private static Path file;
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

    // ----- persistence (own JSON file inside the world folder) -----
    public static void load(MinecraftServer s) {
        server = s;
        file = s.getWorldPath(LevelResource.ROOT).resolve("economymod.json");
        store = new Store();
        try {
            if (Files.exists(file)) {
                Store st = GSON.fromJson(Files.readString(file), Store.class);
                if (st != null) store = st;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void save() {
        if (file == null) return;
        try {
            Files.writeString(file, GSON.toJson(store));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // ----- money -----
    public static P of(ServerPlayer p) {
        return store.players.computeIfAbsent(p.getUUID().toString(), k -> new P());
    }

    public static long balance(ServerPlayer p) {
        return of(p).balance;
    }

    /** amount > 0 = earn, amount < 0 = pay. Balance may go negative (= debt). */
    public static void add(ServerPlayer p, long amount, String why) {
        P s = of(p);
        s.balance += amount;
        p.displayClientMessage(Component.literal(
                (amount >= 0 ? "+" : "") + amount + "$ (" + why + ")  |  Balance: " + s.balance + "$"), true);
    }
}
