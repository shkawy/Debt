package com.example.economymod;

import com.mojang.brigadier.Command;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.entity.event.v1.EntitySleepEvents;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.entity.event.v1.ServerPlayerEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.event.player.PlayerBlockBreakEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.fabricmc.fabric.api.tag.convention.v2.ConventionalBlockTags;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.player.Inventory;

public class Events {

    public static void register() {
        ServerLifecycleEvents.SERVER_STARTED.register(Eco::load);
        ServerLifecycleEvents.SERVER_STOPPING.register(s -> Eco.save());
        ServerTickEvents.END_SERVER_TICK.register(Events::tick);

        // Sleeping costs money (only when you wake up in the morning)
        EntitySleepEvents.STOP_SLEEPING.register((entity, pos) -> {
            if (entity instanceof ServerPlayer p && p.level().getDayTime() % 24000L < 12000L)
                Eco.add(p, -EconomyMod.SLEEP_COST, "sleep");
        });

        // Dying costs money + hostile mobs killed by a player drop coins
        ServerLivingEntityEvents.AFTER_DEATH.register((entity, source) -> {
            if (entity instanceof ServerPlayer p && !Eco.of(p).jailed)
                Eco.add(p, -EconomyMod.DEATH_COST, "death");
            if (source.getEntity() instanceof ServerPlayer && entity instanceof Enemy
                    && entity.level() instanceof ServerLevel sl) {
                int n = 1 + sl.random.nextInt(3);
                entity.spawnAtLocation(sl, new ItemStack(EconomyMod.COIN, n));
            }
        });

        // Jail: mine ores to escape
        PlayerBlockBreakEvents.AFTER.register((world, player, pos, state, be) -> {
            if (!(player instanceof ServerPlayer p)) return;
            Eco.P s = Eco.of(p);
            if (!s.jailed || !state.is(ConventionalBlockTags.ORES)) return;
            s.mined++;
            p.displayClientMessage(Component.literal(
                    "Ores mined: " + s.mined + "/" + EconomyMod.JAIL_ORE_QUOTA), true);
            if (s.mined >= EconomyMod.JAIL_ORE_QUOTA) Jail.release(p);
        });

        // Keep jailed players in jail after logout / death
        ServerPlayConnectionEvents.JOIN.register((handler, sender, server) -> {
            ServerPlayer p = handler.getPlayer();
            if (Eco.of(p).jailed) Jail.send(p);
        });
        ServerPlayerEvents.AFTER_RESPAWN.register((oldP, newP, alive) -> {
            if (Eco.of(newP).jailed) Jail.send(newP);
        });

        registerCommands();
    }

    static void tick(MinecraftServer server) {
        int t = server.getTickCount();
        if (t % 20 != 0) return;
        if (t % 1200 == 0) Eco.save();
        long now = server.overworld().getGameTime();

        for (ServerPlayer p : server.getPlayerList().getPlayers()) {
            Eco.P s = Eco.of(p);
            if (s.jailed) continue;
            if (p.isFallFlying()) Eco.add(p, -EconomyMod.ELYTRA_COST_PER_SECOND, "elytra");

            if (s.balance < 0) {
                if (s.debtSince < 0) {
                    s.debtSince = now;
                    p.sendSystemMessage(Component.literal("You are in DEBT! Pay it within "
                            + (EconomyMod.DEBT_GRACE_TICKS / 1200) + " minutes or go to jail. Use /sell or coins."));
                } else if (now - s.debtSince >= EconomyMod.DEBT_GRACE_TICKS) {
                    Jail.jail(p);
                }
            } else {
                s.debtSince = -1;
            }
        }
    }

    static void registerCommands() {
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> {

            dispatcher.register(Commands.literal("money").executes(c -> {
                ServerPlayer p = c.getSource().getPlayerOrException();
                c.getSource().sendSuccess(() -> Component.literal("Balance: " + Eco.balance(p) + "$"), false);
                return Command.SINGLE_SUCCESS;
            }));

            dispatcher.register(Commands.literal("sell").executes(c -> {
                ServerPlayer p = c.getSource().getPlayerOrException();
                if (Eco.of(p).jailed) {
                    c.getSource().sendFailure(Component.literal("You can't sell in jail."));
                    return 0;
                }
                ItemStack st = p.getMainHandItem();
                int price = Eco.PRICES.getOrDefault(st.getItem(), 0);
                if (price == 0) {
                    c.getSource().sendFailure(Component.literal("This item can't be sold."));
                    return 0;
                }
                long total = (long) price * st.getCount();
                st.setCount(0);
                Eco.add(p, total, "sold");
                return Command.SINGLE_SUCCESS;
            }));

            dispatcher.register(Commands.literal("sellall").executes(c -> {
                ServerPlayer p = c.getSource().getPlayerOrException();
                if (Eco.of(p).jailed) {
                    c.getSource().sendFailure(Component.literal("You can't sell in jail."));
                    return 0;
                }
                long total = 0;
                Inventory inv = p.getInventory();
                for (int i = 0; i < inv.getContainerSize(); i++) {
                    ItemStack st = inv.getItem(i);
                    int price = Eco.PRICES.getOrDefault(st.getItem(), 0);
                    if (price > 0) { total += (long) price * st.getCount(); st.setCount(0); }
                }
                if (total == 0) {
                    c.getSource().sendFailure(Component.literal("Nothing to sell."));
                    return 0;
                }
                Eco.add(p, total, "sold all");
                return Command.SINGLE_SUCCESS;
            }));
        });
    }
}
